<?php
require_once 'Mage/Core/Model/Store.php';

/**
 * This class rounds the price correct to four decimal places
 * 
 * @category  Mage
 * @package   Itabs_BetterPriceRounding
 * @copyright Copyright (c) 2010 ITABS GbR <info@itabs.de>
 * @author    Rouven Alexander Rieker <rouven.rieker@itabs.de>
 */
class Itabs_BetterPriceRounding_Model_Core_Store 
    extends Mage_Core_Model_Store
{
	/**
	 * Constructor
	 */
	protected function _construct()
    {
    	parent::_construct();
    }
	
    /**
     * Round price correct to four decimal places
     *
     * @param mixed $price
     * @return double
     */
    public function roundPrice($price)
    {
        return round($price, 4);
    }
}
<?php
require_once 'Mage/Adminhtml/Block/Catalog/Product/Helper/Form/Price.php';

/**
 * This class provides a overwritten method which rounds correct to four places
 * which is neccessary to have correct prices/numbers.
 * 
 * @category  Mage
 * @package   Itabs_BetterPriceRounding
 * @copyright Copyright (c) 2010 ITABS GbR <info@itabs.de>
 * @author    Rouven Alexander Rieker <rouven.rieker@itabs.de>
 */
class Itabs_BetterPriceRounding_Block_Adminhtml_Catalog_Product_Helper_Form_Price 
    extends Mage_Adminhtml_Block_Catalog_Product_Helper_Form_Price
{	
    /**
     * Returns a number_formatted number rounded correct to four decimal places
     * 
     * @param Varien_Object $index
     * @return float $value
     */
    public function getEscapedValue($index=null)
    {
        $value = $this->getValue();

        if (!is_numeric($value)) {
            return null;
        }

        return number_format($value, 4, null, '');
    }
}
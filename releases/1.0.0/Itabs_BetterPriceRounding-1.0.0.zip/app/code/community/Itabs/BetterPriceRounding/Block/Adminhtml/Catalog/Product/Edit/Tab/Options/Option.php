<?php
require_once 'Mage/Adminhtml/Block/Catalog/Product/Edit/Tab/Options/Option.php';

/**
 * This class provides a overwritten method which rounds correct to four places
 * which is neccessary to have correct prices/numbers.
 * 
 * @category  Mage
 * @package   Itabs_BetterPriceRounding
 * @copyright Copyright (c) 2010 ITABS GbR <info@itabs.de>
 * @author    Rouven Alexander Rieker <rouven.rieker@itabs.de>
 */
class Itabs_BetterPriceRounding_Block_Adminhtml_Catalog_Product_Edit_Tab_Options_Option 
    extends Mage_Adminhtml_Block_Catalog_Product_Edit_Tab_Options_Option
{
    /**
     * Returns a number_formatted number rounded correct to four decimal places
     * 
     * @param float $value
     * @param string $type
     * @return float $value
     */
    public function getPriceValue($value, $type)
    {
        if ($type == 'percent') {
            return number_format($value, 4, null, '');
        } elseif ($type == 'fixed') {
            return number_format($value, 4, null, '');
        }
    }	
}